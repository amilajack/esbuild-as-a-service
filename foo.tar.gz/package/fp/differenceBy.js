var convert = require('./convert'),
    func = convert('differenceBy', require('../differenceBy'));

func.placeholder = require('./placeholder');
module.exports = func;
