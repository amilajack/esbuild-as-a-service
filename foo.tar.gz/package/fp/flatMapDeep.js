var convert = require('./convert'),
    func = convert('flatMapDeep', require('../flatMapDeep'));

func.placeholder = require('./placeholder');
module.exports = func;
